import 'dart:io';

List<String> board = List.generate(9, (index) => (index + 1).toString());
String currentPlayer = 'X';

void main() {
  bool playAgain = true;

  while (playAgain) {
    resetBoard();
    playGame();

    stdout.write('هل تريد لعب جولة جديدة؟ (y/n): ');
    String? choice = stdin.readLineSync();
    playAgain = (choice?.toLowerCase() == 'y');
  }

  print('تم إنهاء اللعبة.');
}

void playGame() {
  String winner = '';
  int moves = 0;

  while (winner == '' && moves < 9) {
    displayBoard();
    int move = getPlayerMove();
    board[move - 1] = currentPlayer;
    moves++;

    if (checkWinner()) {
      winner = currentPlayer;
      displayBoard();
      print('اللاعب $winner فاز!');
      return;
    }

    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
  }

  if (winner == '') {
    displayBoard();
    print('انتهت اللعبة بالتعادل.');
  }
}

void displayBoard() {
  print('');
  for (int i = 0; i < 9; i += 3) {
    print(' ${board[i]} | ${board[i + 1]} | ${board[i + 2]} ');
    if (i < 6) print('---|---|---');
  }
  print('');
}

int getPlayerMove() {
  int? move;

  while (true) {
    stdout.write('اللاعب $currentPlayer، اختر خانة من 1 إلى 9: ');
    String? input = stdin.readLineSync();

    if (input != null && int.tryParse(input) != null) {
      move = int.parse(input);
      if (move >= 1 && move <= 9 && board[move - 1] != 'X' && board[move - 1] != 'O') {
        return move;
      }
    }

    print('إدخال غير صالح. حاول مرة أخرى.');
  }
}

bool checkWinner() {
  List<List<int>> winPositions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
  ];

  for (var pos in winPositions) {
    if (board[pos[0]] == currentPlayer &&
        board[pos[1]] == currentPlayer &&
        board[pos[2]] == currentPlayer) {
      return true;
    }
  }

  return false;
}

void resetBoard() {
  board = List.generate(9, (index) => (index + 1).toString());
  currentPlayer = 'X';
}
